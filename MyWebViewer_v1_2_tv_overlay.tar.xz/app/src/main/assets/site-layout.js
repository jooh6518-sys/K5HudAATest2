(function(){
 'use strict';
 var root=document.documentElement, styleId='mywebviewer-layout-css-v1';
 var old=document.getElementById(styleId);if(old)old.remove();
 var known=!!document.querySelector('.header.header-top .logo-wrapper') &&
           !!document.querySelector('.mobile-main, #index, .details');
 if(!known){root.classList.remove('mwv-layout-active','mwv-page-play');return;}
 var css=__MYWEB_CSS_LITERAL__;
 var style=document.createElement('style');style.id=styleId;style.textContent=css;
 (document.head||root).appendChild(style);
 root.classList.add('mwv-layout-active');
 root.classList.toggle('mwv-page-play',/\/vod\/play\//.test(location.pathname));
 root.classList.toggle('mwv-remote-mode',__MYWEB_REMOTE_LITERAL__);
 // Only hide a card if it is verified as the main advertisement-only card.
 function markAdCard(){
  var ad=document.getElementById('advertiseMain');
  var card=ad&&ad.closest('.card');
  if(card&&!card.querySelector('.movie-list-item,.vod-search-list,.play-select'))
    card.classList.add('mwv-hide-ad-card');
 }
 markAdCard();
 if(!window.__mwvAdObserver){
  var scheduled=false;
  window.__mwvAdObserver=new MutationObserver(function(){
   if(scheduled)return;scheduled=true;
   setTimeout(function(){scheduled=false;markAdCard();},350);
  });
  window.__mwvAdObserver.observe(document.body||document.documentElement,{subtree:true,childList:true});
 }
 // Do not reparent video, iframe or episode links: CSS removes the intervening ad.
})();
