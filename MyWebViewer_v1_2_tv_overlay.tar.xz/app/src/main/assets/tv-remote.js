(function(){
 'use strict';
 window.mwvRemoteEnabled=true;
 document.documentElement.classList.add('mwv-remote-mode');
 if(window.__mwvRemoteInstalled)return;
 window.__mwvRemoteInstalled=true;
 var last=null;
 function visible(el){
   if(!el || !el.isConnected || el.disabled)return false;
   var style=getComputedStyle(el),r=el.getBoundingClientRect();
   return style.visibility!=='hidden' && style.display!=='none' && r.width>=8 && r.height>=8 &&
          !el.closest('[inert],[aria-hidden="true"]');
 }
 function items(){
   return Array.prototype.filter.call(document.querySelectorAll(
      'a[href],button,input:not([type="hidden"]),select,textarea,[role="button"],[tabindex]:not([tabindex="-1"]),.content_playlist a.btn'
   ),visible);
 }
 function focus(el){
   if(!el)return false;
   if(!el.hasAttribute('tabindex') && el.tagName!=='A' && el.tagName!=='INPUT' && el.tagName!=='BUTTON'){
     el.classList.add('mwv-focus-target');el.tabIndex=0;
   }
   try{el.focus({preventScroll:true});}catch(e){el.focus();}
   el.scrollIntoView({block:'nearest',inline:'nearest',behavior:'auto'});
   last=el;return true;
 }
 function point(el){var r=el.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};}
 function move(key){
   var els=items();if(!els.length)return false;
   var a=document.activeElement;
   if(!visible(a) || els.indexOf(a)<0){
     var vh=window.innerHeight,vw=window.innerWidth;
     var first=els.filter(function(el){var r=el.getBoundingClientRect();return r.bottom>0&&r.top<vh;});
     first.sort(function(x,y){var rx=x.getBoundingClientRect(),ry=y.getBoundingClientRect();return rx.top-ry.top || rx.left-ry.left;});
     return focus(first[0]||els[0]);
   }
   var src=point(a), best=null,bestScore=Infinity;
   els.forEach(function(el){
     if(el===a)return;
     var dest=point(el),dx=dest.x-src.x,dy=dest.y-src.y,primary,cross;
     if(key==='ArrowUp'){primary=-dy;cross=Math.abs(dx)}
     else if(key==='ArrowDown'){primary=dy;cross=Math.abs(dx)}
     else if(key==='ArrowLeft'){primary=-dx;cross=Math.abs(dy)}
     else {primary=dx;cross=Math.abs(dy)}
     if(primary<=3)return;
     var score=primary+cross*2.3+(cross>primary*2?cross:0);
     if(score<bestScore){bestScore=score;best=el;}
   });
   return best ? focus(best):false;
 }
 window.mwvTvFocus=function(what){
   var el;
   if(what==='video')el=document.querySelector('#bofang_box #playleft iframe,#bofang_box iframe:not([style*="display: none"])');
   else if(what==='episodes')el=document.querySelector('.play-select .content_playlist a.btn.cr1,.play-select .content_playlist a.btn.active,.play-select .content_playlist a.btn');
   else if(what==='search')el=document.querySelector('input.search-field,input[name="wd"]');
   else if(what==='top')el=items()[0];
   return focus(el);
 };
 document.addEventListener('keydown',function(e){
   if(!window.mwvRemoteEnabled)return;
   var active=document.activeElement;
   if(active && (active.tagName==='INPUT'||active.tagName==='TEXTAREA'||active.tagName==='SELECT'||active.isContentEditable))return;
   if(active&&active.tagName==='IFRAME')return; // Keep original player's remote handling.
   if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].indexOf(e.key)>=0){
     if(move(e.key)){e.preventDefault();e.stopPropagation();}
   }
 },true);
})();
