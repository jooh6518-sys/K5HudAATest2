package com.jooh.mywebviewer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.UiModeManager;
import android.content.Context;
import android.content.res.Configuration;
import android.view.KeyEvent;
import android.graphics.drawable.StateListDrawable;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.content.ActivityNotFoundException;
import java.io.OutputStream;
import org.json.JSONArray;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * 개인용 WebView 앱의 첫 버전.
 * 사이트 디자인을 복제하지 않고 원본 페이지를 그대로 보여줍니다.
 * 주소 수정/저장 및 영상 전체화면 등을 담당하며, CSS/JS 조정은 별도 파일로 분리합니다.
 */
public final class MainActivity extends Activity {

    private static final String PREFS = "my_webviewer_settings_v1";
    private static final String KEY_HOME = "home_address";
    private static final String KEY_LAST = "last_address";
    private static final String KEY_RESTORE = "restore_last";
    private static final String KEY_LAYOUT = "layout_enabled";
    private static final String KEY_KEEP_AWAKE = "keep_screen_on";
    private static final String KEY_TV_REMOTE = "tv_remote_mode";
    private static final String DEFAULT_HOME = "https://tvchak208.com/";
    private static final String STYLE_ID = "mywebviewer-layout-css-v1";

    private static final int MENU_HOME = 1;
    private static final int MENU_REFRESH = 2;
    private static final int MENU_CHANGE_ADDRESS = 3;
    private static final int MENU_SAVE_CURRENT = 4;
    private static final int MENU_LAYOUT = 5;
    private static final int MENU_RESTORE = 6;
    private static final int MENU_AWAKE = 7;
    private static final int MENU_BROWSER = 8;
    private static final int MENU_ABOUT = 9;
    private static final int MENU_EXPORT_HTML = 10;
    private static final int MENU_TV_REMOTE = 11;
    private boolean isRemoteMode;
    private LinearLayout remoteToolbar;
    private Button remoteSettings;
    private static final int REQUEST_HTML_SAVE = 203;
    private String pendingHtml;

    private SharedPreferences preferences;
    private FrameLayout root;
    private WebView webView;
    private ImageButton menuButton;
    private View fullscreenView;
    private WebChromeClient.CustomViewCallback fullscreenCallback;
    private int orientationBeforeFullscreen = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        UiModeManager uiMode = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        boolean isAndroidTv = uiMode != null && uiMode.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION;
        boolean noTouchscreen = !getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        isRemoteMode = preferences.getBoolean(KEY_TV_REMOTE, isAndroidTv || noTouchscreen);

        getWindow().setStatusBarColor(Color.rgb(18, 18, 23));
        getWindow().setNavigationBarColor(Color.rgb(18, 18, 23));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(18, 18, 23));
        setContentView(root);

        createWebView();
        createMenuButton();
        createRemoteToolbar();
        updateRemoteMode();
        updateScreenAwake();

        String initialUrl = getHomeAddress();
        if (preferences.getBoolean(KEY_RESTORE, true)) {
            String last = preferences.getString(KEY_LAST, "");
            if (last != null && isSameSite(last, initialUrl)) {
                initialUrl = last;
            }
        }
        webView.loadUrl(initialUrl);
    }

    private void createWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(18, 18, 23));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            settings.setSafeBrowsingEnabled(true);
        }

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                Uri target = request.getUrl();
                String scheme = target.getScheme();
                if (scheme == null) return true;
                if (scheme.equalsIgnoreCase("https")) return false;
                // 사용자 클릭으로 호출된 전화/메일 링크만 외부 앱에서 처리.
                if (request.hasGesture() && (scheme.equalsIgnoreCase("tel") || scheme.equalsIgnoreCase("mailto"))) {
                    openExternal(target);
                }
                // intent:, javascript:, file:, data:, http: 등은 메인 프레임에서 차단.
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null && isSameSite(url, getHomeAddress())) {
                    preferences.edit().putString(KEY_LAST, url).apply();
                }
                applyLayoutIfEnabled();
                applyRemoteNavigation();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    toast("페이지를 열지 못했습니다. 주소 또는 네트워크를 확인해주세요.");
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                showVideoFullscreen(view, callback);
            }

            @Override
            public void onHideCustomView() {
                hideVideoFullscreen();
            }
        });

        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void createMenuButton() {
        menuButton = new ImageButton(this);
        menuButton.setContentDescription("앱 설정 열기");
        menuButton.setImageResource(android.R.drawable.ic_menu_manage);
        menuButton.setImageTintList(ColorStateList.valueOf(Color.WHITE));
        menuButton.setScaleType(ImageButton.ScaleType.CENTER_INSIDE);
        menuButton.setPadding(dp(11), dp(11), dp(11), dp(11));

        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.rgb(24, 49, 83));
        background.setCornerRadius(dp(32));
        menuButton.setBackground(background);
        menuButton.setAlpha(0.92f);
        menuButton.setElevation(dp(6));
        menuButton.setOnClickListener(v -> showAppMenu());

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(46), dp(46));
        params.gravity = Gravity.END | Gravity.BOTTOM;
        params.setMargins(dp(12), dp(12), dp(14), dp(18));
        root.addView(menuButton, params);
    }

    private void createRemoteToolbar() {
        remoteToolbar = new LinearLayout(this);
        remoteToolbar.setOrientation(LinearLayout.HORIZONTAL);
        remoteToolbar.setGravity(Gravity.CENTER_VERTICAL);
        remoteToolbar.setPadding(dp(8), dp(4), dp(8), dp(4));
        remoteToolbar.setBackgroundColor(Color.rgb(15, 30, 49));
        addRemoteButton("뒤로", () -> onBackPressed());
        addRemoteButton("홈", () -> webView.loadUrl(getHomeAddress()));
        addRemoteButton("검색", this::focusSearch);
        addRemoteButton("영상", () -> focusSiteElement("video"));
        addRemoteButton("회차", () -> focusSiteElement("episodes"));
        addRemoteButton("새로고침", () -> webView.reload());
        remoteSettings = addRemoteButton("설정", this::showAppMenu);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(64), Gravity.TOP);
        root.addView(remoteToolbar, lp);
    }

    private Button addRemoteButton(String label, Runnable action) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setPadding(dp(3), 0, dp(3), 0);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setFocusable(true);
        button.setFocusableInTouchMode(false);
        StateListDrawable background = new StateListDrawable();
        GradientDrawable selected = new GradientDrawable();
        selected.setColor(Color.rgb(201, 117, 29));
        selected.setCornerRadius(dp(7));
        GradientDrawable normal = new GradientDrawable();
        normal.setColor(Color.rgb(28, 51, 78));
        normal.setCornerRadius(dp(7));
        background.addState(new int[]{android.R.attr.state_focused}, selected);
        background.addState(new int[]{}, normal);
        button.setBackground(background);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(52), 1f);
        params.setMargins(dp(2), 0, dp(2), 0);
        remoteToolbar.addView(button, params);
        button.setOnClickListener(v -> action.run());
        button.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                webView.requestFocus();
                focusSiteElement("top");
                return true;
            }
            return false;
        });
        return button;
    }

    private void updateRemoteMode() {
        if (remoteToolbar == null || webView == null) return;
        remoteToolbar.setVisibility(isRemoteMode ? View.VISIBLE : View.GONE);
        menuButton.setVisibility(isRemoteMode ? View.GONE : View.VISIBLE);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) webView.getLayoutParams();
        lp.topMargin = isRemoteMode ? dp(64) : 0;
        webView.setLayoutParams(lp);
        if (isRemoteMode) remoteToolbar.getChildAt(1).requestFocus();
        else webView.requestFocus();
        webView.evaluateJavascript("window.mwvRemoteEnabled=" + (isRemoteMode ? "true" : "false") + ";document.documentElement.classList.toggle('mwv-remote-mode'," + (isRemoteMode ? "true" : "false") + ");", null);
    }

    private void applyRemoteNavigation() {
        if (!isRemoteMode || webView == null) return;
        try {
            webView.evaluateJavascript(readAsset("tv-remote.js"), null);
        } catch (IOException ignored) { toast("리모컨 설정 파일을 읽지 못했습니다."); }
    }

    private void focusSiteElement(String name) {
        webView.requestFocus();
        String safeName = name.equals("video") ? "video" : name.equals("episodes") ? "episodes" : "top";
        String script = "(function(){return window.mwvTvFocus ? window.mwvTvFocus('" + safeName + "') : false;})()";
        webView.evaluateJavascript(script, result -> {
            if (!"true".equals(result) && "video".equals(safeName)) toast("이 페이지에서 영상 영역을 찾지 못했습니다.");
            if (!"true".equals(result) && "episodes".equals(safeName)) toast("이 페이지에서 회차 목록을 찾지 못했습니다.");
        });
    }

    private void focusSearch() {
        webView.requestFocus();
        webView.evaluateJavascript("(function(){var e=document.querySelector('input.search-field,input[name=wd]');if(!e)return false;e.focus();e.scrollIntoView({block:'center'});return true;})()", result -> {
            if ("true".equals(result)) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(webView, InputMethodManager.SHOW_IMPLICIT);
            } else toast("검색창을 찾지 못했습니다.");
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (isRemoteMode && keyCode == KeyEvent.KEYCODE_MENU) {
            showAppMenu();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void showAppMenu() {
        PopupMenu popup = new PopupMenu(this, isRemoteMode && remoteSettings != null ? remoteSettings : menuButton);
        Menu menu = popup.getMenu();
        menu.add(0, MENU_HOME, 0, "저장한 홈 주소로 이동");
        menu.add(0, MENU_REFRESH, 1, "새로고침");
        menu.add(0, MENU_CHANGE_ADDRESS, 2, "사이트 주소 변경 · 저장");
        menu.add(0, MENU_SAVE_CURRENT, 3, "현재 페이지를 홈 주소로 저장");
        menu.add(0, MENU_LAYOUT, 4, "레이아웃 적용: " + (preferences.getBoolean(KEY_LAYOUT, true) ? "켜짐" : "꺼짐"));
        menu.add(0, MENU_TV_REMOTE, 5, "리모컨 모드: " + (isRemoteMode ? "켜짐" : "꺼짐"));
        menu.add(0, MENU_EXPORT_HTML, 5, "현재 페이지 HTML 저장");
        menu.add(0, MENU_RESTORE, 6, "마지막 페이지 복원: " + (preferences.getBoolean(KEY_RESTORE, true) ? "켜짐" : "꺼짐"));
        menu.add(0, MENU_AWAKE, 7, "화면 켜짐 유지: " + (preferences.getBoolean(KEY_KEEP_AWAKE, false) ? "켜짐" : "꺼짐"));
        menu.add(0, MENU_BROWSER, 8, "현재 페이지를 외부 브라우저로 열기");
        menu.add(0, MENU_ABOUT, 9, "앱 정보");
        popup.setOnMenuItemClickListener(this::onAppMenuClicked);
        popup.show();
    }

    private boolean onAppMenuClicked(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case MENU_HOME:
                webView.loadUrl(getHomeAddress());
                return true;
            case MENU_REFRESH:
                webView.reload();
                return true;
            case MENU_CHANGE_ADDRESS:
                showChangeAddressDialog();
                return true;
            case MENU_SAVE_CURRENT:
                confirmSaveCurrentAddress();
                return true;
            case MENU_LAYOUT:
                boolean newLayout = !preferences.getBoolean(KEY_LAYOUT, true);
                preferences.edit().putBoolean(KEY_LAYOUT, newLayout).apply();
                applyLayoutIfEnabled();
                if (!newLayout) webView.reload(); // restore any relocated nodes
                toast("레이아웃 적용: " + (newLayout ? "켜짐" : "꺼짐"));
                return true;
            case MENU_TV_REMOTE:
                isRemoteMode = !isRemoteMode;
                preferences.edit().putBoolean(KEY_TV_REMOTE, isRemoteMode).apply();
                updateRemoteMode();
                applyLayoutIfEnabled();
                applyRemoteNavigation();
                toast("리모컨 모드: " + (isRemoteMode ? "켜짐" : "꺼짐"));
                return true;
            case MENU_EXPORT_HTML:
                exportCurrentPageHtml();
                return true;
            case MENU_RESTORE:
                boolean newRestore = !preferences.getBoolean(KEY_RESTORE, true);
                preferences.edit().putBoolean(KEY_RESTORE, newRestore).apply();
                toast("마지막 페이지 복원: " + (newRestore ? "켜짐" : "꺼짐"));
                return true;
            case MENU_AWAKE:
                boolean newAwake = !preferences.getBoolean(KEY_KEEP_AWAKE, false);
                preferences.edit().putBoolean(KEY_KEEP_AWAKE, newAwake).apply();
                updateScreenAwake();
                toast("화면 켜짐 유지: " + (newAwake ? "켜짐" : "꺼짐"));
                return true;
            case MENU_BROWSER:
                String url = webView.getUrl();
                if (isHttpsUrl(url)) openExternal(Uri.parse(url));
                else toast("열 수 있는 페이지 주소가 없습니다.");
                return true;
            case MENU_ABOUT:
                new AlertDialog.Builder(this)
                        .setTitle("내 웹뷰 1.2")
                        .setMessage("원본 사이트의 페이지를 그대로 여는 개인용 앱입니다.\n\n" +
                                "홈 주소 변경과 저장, 최근 페이지 복원, 뒤로 가기, 동영상 전체화면을 지원합니다.\n\n" +
                                "광고·추천영상·푸터 숨김, 화면 크기별 배치, TV 리모컨 조작을 지원합니다.\n\n" +
                                "HTML 저장 기능은 민감정보를 최대한 제거한 현재 페이지 구조를 보관합니다.")
                        .setPositiveButton("확인", null)
                        .show();
                return true;
            default:
                return false;
        }
    }

    private void showChangeAddressDialog() {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(22), dp(12), dp(22), dp(4));

        TextView explanation = new TextView(this);
        explanation.setText("사이트 주소가 바뀌면 새 HTTPS 주소를 입력하세요. 저장한 주소는 앱을 종료해도 유지됩니다.");
        explanation.setTextSize(14);
        body.addView(explanation);

        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        field.setText(getHomeAddress());
        field.setSelectAllOnFocus(true);
        field.setHint("https://example.com/");
        body.addView(field, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("사이트 주소 변경")
                .setView(body)
                .setNegativeButton("취소", null)
                .setPositiveButton("저장하고 열기", null)
                .create();
        dialog.setOnShowListener(unused -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                String newHome = normalizeHttpsAddress(field.getText().toString());
                setHomeAddress(newHome);
                webView.loadUrl(newHome);
                dialog.dismiss();
                toast("새 사이트 주소를 저장했습니다.");
            } catch (IllegalArgumentException e) {
                field.setError(e.getMessage());
            }
        }));
        dialog.show();
    }

    private void confirmSaveCurrentAddress() {
        String current = webView.getUrl();
        if (!isHttpsUrl(current)) {
            toast("저장할 HTTPS 페이지가 없습니다.");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("현재 페이지 저장")
                .setMessage("이 주소를 새 시작 주소로 저장할까요?\n\n" + current)
                .setNegativeButton("취소", null)
                .setPositiveButton("저장", (dialog, which) -> {
                    setHomeAddress(current);
                    toast("현재 페이지를 시작 주소로 저장했습니다.");
                })
                .show();
    }

    private void setHomeAddress(String home) {
        // 시작 주소가 달라지면 이전 도메인의 마지막 페이지를 자동 복원하지 않도록 초기화.
        preferences.edit().putString(KEY_HOME, home).remove(KEY_LAST).apply();
    }

    private String getHomeAddress() {
        String stored = preferences.getString(KEY_HOME, DEFAULT_HOME);
        return stored == null || stored.trim().isEmpty() ? DEFAULT_HOME : stored;
    }

    private String normalizeHttpsAddress(String raw) {
        String value = raw == null ? "" : raw.trim();
        if (value.isEmpty()) throw new IllegalArgumentException("주소를 입력해주세요.");
        if (value.contains(" ") || value.contains("\n") || value.contains("\r") || value.contains("\t")) {
            throw new IllegalArgumentException("주소에 공백을 사용할 수 없습니다.");
        }
        if (!value.contains("://")) value = "https://" + value;
        Uri uri = Uri.parse(value);
        if (!"https".equalsIgnoreCase(uri.getScheme())) {
            throw new IllegalArgumentException("보안을 위해 HTTPS 주소만 지원합니다.");
        }
        if (uri.getHost() == null || uri.getHost().trim().isEmpty() || uri.getUserInfo() != null) {
            throw new IllegalArgumentException("올바른 사이트 주소를 입력해주세요.");
        }
        return uri.toString();
    }

    private boolean isHttpsUrl(String url) {
        if (url == null || url.isEmpty()) return false;
        Uri uri = Uri.parse(url);
        return "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null;
    }

    private boolean isSameSite(String page, String home) {
        if (!isHttpsUrl(page) || !isHttpsUrl(home)) return false;
        String actual = Uri.parse(page).getHost().toLowerCase(Locale.ROOT);
        String expected = Uri.parse(home).getHost().toLowerCase(Locale.ROOT);
        return actual.equals(expected) || actual.equals("www." + expected) || expected.equals("www." + actual);
    }

    private void applyLayoutIfEnabled() {
        if (webView == null || !isHttpsUrl(webView.getUrl())) return;
        if (!preferences.getBoolean(KEY_LAYOUT, true)) {
            webView.evaluateJavascript("(function(){var s=document.getElementById('" + STYLE_ID + "');if(s)s.remove();document.documentElement.classList.remove('mwv-layout-active');document.documentElement.classList.toggle('mwv-remote-mode'," + (isRemoteMode ? "true" : "false") + ");})();", null);
            return;
        }
        try {
            String css = readAsset("site-layout.css");
            String template = readAsset("site-layout.js");
            // JSON 문자열 리터럴로 인코딩하여 CSS 안의 따옴표/줄바꿈이 JS를 깨뜨리지 않도록 함.
            String script = template.replace("__MYWEB_CSS_LITERAL__", JSONObject.quote(css))
                    .replace("__MYWEB_REMOTE_LITERAL__", isRemoteMode ? "true" : "false");
            webView.evaluateJavascript(script, null);
        } catch (IOException e) {
            toast("레이아웃 파일을 불러오지 못했습니다.");
        }
    }

    private void exportCurrentPageHtml() {
        if (webView == null || !isHttpsUrl(webView.getUrl())) {
            toast("먼저 페이지를 열어주세요.");
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("현재 페이지 HTML 저장")
                .setMessage("현재 페이지의 HTML 구조를 파일로 저장합니다. 링크 및 스크립트 등 민감할 수 있는 속성을 제거하지만 저장한 파일은 공유 전에 확인하세요. 외부 iframe 내부 내용은 포함하지 않습니다.")
                .setNegativeButton("취소", null)
                .setPositiveButton("추출", (d, which) -> {
                    try {
                        String script = readAsset("page-snapshot.js");
                        webView.evaluateJavascript(script, value -> {
                            try {
                                String json = new JSONArray("[" + value + "]").getString(0);
                                JSONObject data = new JSONObject(json);
                                if (data.has("error")) {
                                    toast("추출 실패: " + data.optString("error"));
                                    return;
                                }
                                pendingHtml = "<!-- Source: " + data.optString("url") + " -->\n" + data.getString("html");
                                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                                intent.addCategory(Intent.CATEGORY_OPENABLE);
                                intent.setType("text/html");
                                String filename = "webview-page-" + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date()) + ".html";
                                intent.putExtra(Intent.EXTRA_TITLE, filename);
                                startActivityForResult(intent, REQUEST_HTML_SAVE);
                            } catch (Exception e) {
                                toast("HTML 처리 오류가 발생했습니다.");
                            }
                        });
                    } catch (IOException e) {
                        toast("HTML 추출 파일을 불러오지 못했습니다.");
                    }
                }).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_HTML_SAVE) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null || pendingHtml == null) {
            pendingHtml = null;
            return;
        }
        try (OutputStream stream = getContentResolver().openOutputStream(data.getData())) {
            if (stream == null) throw new IOException("No output stream");
            stream.write(pendingHtml.getBytes(StandardCharsets.UTF_8));
            stream.flush();
            toast("HTML 파일을 저장했습니다.");
        } catch (Exception e) {
            toast("HTML 저장에 실패했습니다.");
        } finally {
            pendingHtml = null;
        }
    }

    private String readAsset(String name) throws IOException {
        StringBuilder builder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                getAssets().open(name), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) builder.append(line).append('\n');
        }
        return builder.toString();
    }

    private void showVideoFullscreen(View view, WebChromeClient.CustomViewCallback callback) {
        if (fullscreenView != null) {
            callback.onCustomViewHidden();
            return;
        }
        fullscreenView = view;
        fullscreenCallback = callback;
        orientationBeforeFullscreen = getRequestedOrientation();

        if (view.getParent() instanceof ViewGroup) {
            ((ViewGroup) view.getParent()).removeView(view);
        }
        view.setBackgroundColor(Color.BLACK);
        root.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        webView.setVisibility(View.INVISIBLE);
        menuButton.setVisibility(View.GONE);
        if (remoteToolbar != null) remoteToolbar.setVisibility(View.GONE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    }

    private void hideVideoFullscreen() {
        if (fullscreenView == null) return;
        root.removeView(fullscreenView);
        fullscreenView = null;
        webView.setVisibility(View.VISIBLE);
        menuButton.setVisibility(isRemoteMode ? View.GONE : View.VISIBLE);
        if (remoteToolbar != null) remoteToolbar.setVisibility(isRemoteMode ? View.VISIBLE : View.GONE);
        getWindow().getDecorView().setSystemUiVisibility(0);
        setRequestedOrientation(orientationBeforeFullscreen);
        if (fullscreenCallback != null) {
            WebChromeClient.CustomViewCallback callback = fullscreenCallback;
            fullscreenCallback = null;
            callback.onCustomViewHidden();
        }
    }

    private void openExternal(Uri target) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, target));
        } catch (ActivityNotFoundException | SecurityException e) {
            toast("이 링크를 처리할 앱이 없습니다.");
        }
    }

    private void updateScreenAwake() {
        if (preferences.getBoolean(KEY_KEEP_AWAKE, false)) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (fullscreenView != null) {
            hideVideoFullscreen();
        } else if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        if (preferences != null) updateScreenAwake();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (fullscreenView != null) hideVideoFullscreen();
        if (webView != null) {
            webView.stopLoading();
            root.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
