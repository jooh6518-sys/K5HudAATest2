plugins {
    id("com.android.application")
}

android {
    namespace = "com.jooh.mywebviewer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jooh.mywebviewer"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
