# Android Studio가 설치된 Windows PC에서 실행하는 로컬 빌드 도우미.
# 공식 Gradle 8.9 배포본을 다운로드하고 배포 SHA-256 체크섬을 확인합니다.
# Android SDK 및 Java 17은 설치되어 있어야 합니다.
param([switch]$CreateWrapperOnly)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$cache = Join-Path $root '.build-tools'
$zip = Join-Path $cache 'gradle-8.9-bin.zip'
$gradleExe = Join-Path $cache 'gradle-8.9\bin\gradle.bat'

if (-not (Test-Path $cache)) { New-Item -Path $cache -ItemType Directory | Out-Null }

if (-not $env:JAVA_HOME) {
    $studioJbr = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
    if (Test-Path (Join-Path $studioJbr 'bin\java.exe')) { $env:JAVA_HOME = $studioJbr }
}
if (-not $env:ANDROID_HOME) {
    $sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk'
    if (Test-Path $sdk) { $env:ANDROID_HOME = $sdk }
}

$distUrl = 'https://services.gradle.org/distributions/gradle-8.9-bin.zip'
$shaUrl = $distUrl + '.sha256'
Write-Host '공식 Gradle SHA-256 확인 중...'
$expected = ([string](Invoke-RestMethod -Uri $shaUrl)).Trim().Split(' ')[0].ToUpperInvariant()
if ($expected -notmatch '^[0-9A-F]{64}$') { throw '공식 체크섬을 확인하지 못했습니다.' }
if (-not (Test-Path $zip)) {
    Write-Host 'Gradle 8.9 다운로드 중...'
    Invoke-WebRequest -Uri $distUrl -OutFile $zip
}
$actual = (Get-FileHash -Algorithm SHA256 -Path $zip).Hash.ToUpperInvariant()
if ($expected -ne $actual) { throw '다운로드한 Gradle 파일의 SHA-256 검증에 실패했습니다.' }

if (-not (Test-Path $gradleExe)) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $cache)
}

Push-Location $root
try {
    Write-Host '표준 Gradle Wrapper 생성 중...'
    & $gradleExe wrapper --gradle-version '8.9' --distribution-type 'bin'
    if ($LASTEXITCODE -ne 0) { throw 'Gradle Wrapper 생성 실패. JDK 17과 Android SDK 설치 상태를 확인하세요.' }

    if (-not $CreateWrapperOnly) {
        Write-Host 'APK 컴파일 중...'
        & $gradleExe ':app:assembleDebug'
        if ($LASTEXITCODE -ne 0) { throw 'APK 컴파일 실패. Android Studio 설치와 SDK Platform 35를 확인하세요.' }
        Write-Host 'APK 생성: app\build\outputs\apk\debug\app-debug.apk'
    }
} finally {
    Pop-Location
}
