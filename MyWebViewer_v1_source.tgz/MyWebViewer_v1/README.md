# 내 웹뷰 v1.0 — 안드로이드 개인용 WebView 앱

> **중요:** 이것은 소스 프로젝트입니다. 이 대화의 실행 환경에는 Android SDK/Gradle이 없어 APK 컴파일 및 실기기 테스트를 완료하지 못했습니다. 파일을 APK라고 잘못 표기하지 않았습니다.

## 구현된 기능

- 원본 웹사이트를 **Android WebView**로 표시 (기존 디자인과 사이트 상단 메뉴 유지)
- 기본 주소: `https://tvchak208.com/`
- 앱 우하단 **톱니바퀴 버튼** → **사이트 주소 변경 · 저장**
- `https://새도메인.com` 입력 가능. 저장한 주소는 **앱 종료 후에도 유지**됨
- 기본 주소 변경 시 이전 도메인의 마지막 페이지 기록 초기화
- **마지막 페이지 자동 복원** (기본 켜짐, 동일 호스트에 한함)
- 홈으로 이동, 새로고침, 현재 주소를 홈 주소로 저장, 외부 브라우저 열기
- 안드로이드 뒤로가기 (재생 전체화면 우선 종료, 그다음 웹 히스토리)
- WebChromeClient 기반 HTML5 영상 전체화면 / 가로 회전
- 쿠키 / LocalStorage 유지, JS 사용
- 화면 켜짐 유지 ON/OFF
- 앱 내 **레이아웃 적용 준비 ON/OFF** (별도 CSS/JS 주입 구조)

## 아직 구현하지 않은 기능 (실제 HTML DOM 확인 필요)

광고 숨김, 추천영상 숨김, 푸터 숨김, 회차 목록 이동, 플레이어 너비 확대는 요구사항으로 파일 `app/src/main/assets/layout-settings.json`에 **확정 기록**되어 있습니다. 하지만 스크린샷만으로 실제 HTML 선택자를 검증할 수 없어 **v1에서는 사이트 DOM을 변경하지 않습니다.** `site-layout.css`와 `site-layout.js`는 안전한 주입용 준비 파일입니다.

특정 웹사이트는 WebView 접근/재생을 막을 수 있습니다. 이 프로젝트는 그런 제한이나 콘텐츠 권한 확인을 우회하지 않습니다.

## Windows에서 APK 빌드 (추천)

1. [Android Studio](https://developer.android.com/studio)를 설치하고 첫 실행에서 **Android SDK Platform 35**를 설치합니다. JDK 17이 필요하며 Android Studio 자체 JBR을 사용할 수 있습니다.
2. 압축을 풀고 `MyWebViewer_v1` 폴더를 열어 둡니다.
3. Windows PowerShell에서 프로젝트 폴더로 이동하여 다음을 실행합니다.

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\build-apk.ps1
   ```

   첫 실행에는 공식 Gradle 8.9를 다운로드하고 **공식 SHA-256 체크섬을 확인**한 후 표준 Gradle Wrapper를 생성하고 디버그 APK를 빌드합니다.

4. 빌드 성공 시 생성되는 설치 파일:

   `app\build\outputs\apk\debug\app-debug.apk`

5. 이 APK 파일을 스마트폰/태블릿으로 복사해서 설치합니다. 파일 출처가 본인에게서 온 것이 맞는지 확인하세요. **디버그 APK는 개인 테스트용**입니다.

### Android Studio로 직접 빌드하기

먼저 위 `build-apk.ps1 -CreateWrapperOnly` 명령으로 표준 Gradle Wrapper 파일을 만든 뒤 Android Studio에서 폴더를 **File → Open**으로 엽니다. Gradle 동기화 후 **Build → Build APK(s)**로 생성합니다.

## Android Studio를 설치하기 싫다면: GitHub Actions 빌드

프로젝트 폴더 **내용 전체**를 본인의 GitHub 저장소에 업로드합니다. `.github/workflows/build-apk.yml`이 포함되어 있으면 **Actions → Build Android APK → Run workflow**를 실행할 수 있습니다. 빌드 완료 후 `MyWebViewer-debug-apk` 아티팩트를 다운로드하고 압축을 풀면 APK가 있습니다. 저장소는 **비공개(Private)**로 만드는 것을 권장합니다.

## 사용법

- 앱 처음 실행 시 `https://tvchak208.com/`로 이동합니다.
- 도메인이 변경되면 우하단 **톱니바퀴**를 눌러 `사이트 주소 변경 · 저장`에서 **새로운 전체 URL**을 입력합니다. 도메인만 입력해도 `https://`가 자동 추가됩니다.
- 앱 재실행 시 시작 주소 또는 (설정이 켜져 있으면) 같은 도메인의 마지막 방문 페이지를 복원합니다.
- 플레이어가 전체화면을 지원하면 전체화면 진입 시 가로 화면으로 전환합니다.
- 웹사이트의 렌더링·스트리밍 지원은 원본 사이트와 Android System WebView 구현에 따라 달라지므로 실제 기기에서 검증해야 합니다.

## 주요 파일

- `app/src/main/java/com/jooh/mywebviewer/MainActivity.java`: WebView와 URL 저장, 기본 UI, 전체화면
- `app/src/main/assets/layout-settings.json`: 합의된 레이아웃 요구사항
- `app/src/main/assets/site-layout.css`: 향후 CSS 선택자 추가 위치
- `app/src/main/assets/site-layout.js`: 페이지에 CSS 적용/해제용 스크립트
- `app/src/main/AndroidManifest.xml`: 네트워크, 앱 설정
- `.github/workflows/build-apk.yml`: GitHub에서 다운로드 가능한 APK 빌드 자동화

## 보안 및 범위

- 주소는 HTTPS만 허용합니다. 로컬에 `SharedPreferences`로 보관하며 서버로 별도 전송하지 않습니다.
- 앱에서 별도 광고 차단 네트워크 프록시, 스트리밍 수집·다운로드, CAPTCHA 우회, 쿠키 탈취는 하지 않습니다.
- 웹사이트에서 직접 기록되는 로그인/쿠키/방문 내역은 WebView 정책에 따릅니다.
- 앱이 사용자 입력 URL을 직접 열기 때문에 신뢰할 수 있는 웹사이트 주소만 사용하세요.
