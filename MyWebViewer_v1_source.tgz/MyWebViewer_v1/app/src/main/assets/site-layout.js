/*
 * 안전한 스타일 적용/해제. 원본 페이지 DOM이나 이벤트를 파괴하지 않습니다.
 * 이 스크립트는 페이지 로드 완료 후 WebView에서 실행됩니다.
 */
(function () {
  'use strict';
  var tag = 'mywebviewer-layout-css-v1';
  var old = document.getElementById(tag);
  if (old) old.remove();
  var css = __MYWEB_CSS_LITERAL__;
  if (css && css.trim().length) {
    var style = document.createElement('style');
    style.id = tag;
    style.textContent = css;
    (document.head || document.documentElement).appendChild(style);
  }
})();
